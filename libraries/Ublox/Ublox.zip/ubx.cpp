#include <ubx.h>

void UBX::begin(byte *wa,int l)
{
	workarea = wa;
	max_length = l;
	state = WAIT_S1;
	offset = 0;
}
/*
   if space, add to buffer & parse,
   if at end and correct checksum, return true;
*/
bool UBX::parse(byte b)
{
	bool rc = false;
	// if space available, handle it, else start over
	if (offset >= max_length)
	{
		offset = 0;
		state = WAIT_S1;
	}
	else
	{
		switch(state)
		{
			case WAIT_S1:
				if (b == 0xb5)
				{
					workarea[0] = 0xb5;
					offset = 1;
					state = WAIT_S2;
				}
				break;
			case WAIT_S2:
				if (b == 0x62)
				{
					workarea[offset++] = 0x62;
					offset = 1;
					state = WAIT_CLASS;
				}
				else
					state = WAIT_S1;
				break;
			case WAIT_CLASS:
				workarea[offset++] = b;
				state = WAIT_ID;
				break;
			case WAIT_ID:
				workarea[offset++] = b;
				state = WAIT_L1;
				break;
			case WAIT_L1:
				workarea[offset++] = b;
				payloadlength = b;
				state = WAIT_L2;
				break;
			case WAIT_L2:
				workarea[offset++] = b;
				payloadlength |= b<<8;
				// sanity check that message can fit into this buffer
				if ((payloadlength+8) <= max_length)
					state = WAIT_CS1;
				else
					state = WAIT_S1;
				break;
			case WAIT_CS1:
				// add to payload until payload exhausted
				workarea[offset++] = b;
				if (--payloadlength == 0)
					state = WAIT_CS2;
				break;
			case WAIT_CS2:
				workarea[offset] = b;
				state = WAIT_S1;
				// complete message, now do checksum
				Checksum(&workarea[2],offset-4);
				rc = workarea[offset-2] == CK_A && workarea[offset-1] == CK_B;
				break;
			};	
		}
	}
	return rc;
}