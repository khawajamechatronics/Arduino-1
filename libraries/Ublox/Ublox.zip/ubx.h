/*
    General purpose library for servicing UBX data stram
*/
#include <inttypes.h>

#define SYNC1 0xb5
#define SYNC2 0x62
enum eState {WAIT_S1,WAIT_S2,WAIT_CLASS,WAIT_ID,WAIT_L1,WAIT_L2,WAIT_CS1,WAIT_CS2}; // Parser state machine
class UBX {
	public:
		enum eClass {NAV=1,RXM,INF=4,ACK,CFG,MON=10,AID,TIM=13};
		enum eACKid {NAK,ACK};
		enum eAIDid {REQ=0,INI,HUI,DATA=16,ALM=0X30,EPH,ALPSRV,AOP,ALP=0X50};
		enum eNAVid {POSLLH=2,STATUS,TIMEUTC=0X21};
		bool parse(byte);   // true for complete message, will be contained in the work buffer
		void begin(byte *,int);  // initialize with pointer to work buffer
		void Checksum(byte *buffer,int length); // see ublox manual
		// CS is calculated checksum after calling Checksum
		byte CS[2];	// CK_A, CK_B
	private:
		enum eState state;
		byte *workarea;
		int max_length;
		int offset;
		uint16_t payloadlength;
}
